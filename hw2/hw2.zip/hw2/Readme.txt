Homework 2
Hi all,
Here is your new homework. Please reach out to students dataset from 
https://userpage.fu-berlin.de/soga/200/2010_data_sets/students.csv
This dataset gives a set of demographic and education information about ~9000 student and their salaries after graduation. 
Your main focus for this project should be discovering hidden patterns on this dataset using data visualization 
and summary statistics. You can work/relate any of the variables but make sure you create advanced plots with ggplot2.  
You are supposed to submit a statistical report of your findings ideally via RMarkdown by 5th of April.
RMarkdown https://rmarkdown.rstudio.com/articles_intro.html 
Thanks,
Eralp
